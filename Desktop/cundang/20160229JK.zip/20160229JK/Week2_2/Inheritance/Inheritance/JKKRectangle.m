//
//  JKKRectangle.m
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "JKKRectangle.h"

@implementation JKKRectangle
-(int)area {
    return width * height;
}
@end
