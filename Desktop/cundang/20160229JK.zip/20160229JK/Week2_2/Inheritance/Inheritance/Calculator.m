//
//  Calculator.m
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "Calculator.h"
@interface Calculator()

@end

@implementation Calculator
-(void)print {
    NSLog(@"the value of calculator is %lf",accumulator);
}
@end
