//
//  JKKCalculator.m
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "JKKCalculator.h"

@implementation JKKCalculator
-(void)print {
    NSLog(@"%@\'s accumulator value:%lf",[self class],accumulator);
}
@end
