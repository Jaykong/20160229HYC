//
//  JKKRectangle.h
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JKKRectangle : NSObject
{
    int width;
    int height;
}
-(int)area;
@end
