//
//  Square1.m
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "Square1.h"

@implementation Square1
-(void)print {
    side = width;
    side = height;
}
@end
