//
//  Calculator.h
//  Inheritance
//
//  Created by trainer on 3/9/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Calculator : NSObject
{
    double accumulator;
}
-(void)print;
-(void)unImplentation;
@end
