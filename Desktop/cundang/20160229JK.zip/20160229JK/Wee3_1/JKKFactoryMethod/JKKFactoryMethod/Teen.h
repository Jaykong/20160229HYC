//
//  Teen.h
//  JKKFactoryMethod
//
//  Created by trainer on 3/14/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "Person.h"

@interface Teen : Person

@end
