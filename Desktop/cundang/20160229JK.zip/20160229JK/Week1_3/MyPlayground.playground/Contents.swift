//: Playground - noun: a place where people can play

let numStr = "15"
let num = Int(numStr)

let str = "hello"
let numStr2 = Int(str)
let a = "a"
a
//Character
//String





