//
//  main.swift
//  JKUMLSwift
//
//  Created by trainer on 3/7/16.
//  Copyright © 2016 trainer. All rights reserved.
//

public class Professor {
    
}

public class Student {
    public let n:[Professor] = []
    
}



