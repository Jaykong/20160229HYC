//
//  main.swift
//  SwiftFraction2
//
//  Created by trainer on 3/7/16.
//  Copyright © 2016 traineres. All rights reserved.
//

import Foundation

let frac = Fraction2()
frac.numerator = 3;
frac.denominator = 4;
frac.description()
print(frac.numerator)

