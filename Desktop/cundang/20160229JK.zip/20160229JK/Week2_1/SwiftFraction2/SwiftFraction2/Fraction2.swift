//
//  Fraction2.swift
//  SwiftFraction2
//
//  Created by trainer on 3/7/16.
//  Copyright © 2016 traineres. All rights reserved.
//

import Foundation

class Fraction2 {
    var numerator = 0
    var denominator = 0
    
    func description() {
        print("the fraction is \(numerator)/\(denominator)")
    }
}

let frac2 = Fraction2()



