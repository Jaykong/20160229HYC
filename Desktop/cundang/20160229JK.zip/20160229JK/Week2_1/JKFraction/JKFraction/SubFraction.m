//
//  SubFraction.m
//  JKFraction
//
//  Created by trainer on 3/7/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "SubFraction.h"

@implementation SubFraction
-(void)addSubFraction:(SubFraction *)sf {
//    denominator = sf.denominator;
//    numerator = sf.numerator;
    
}
@end
