//
//  main.m
//  JKFraction
//
//  Created by trainer on 3/7/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fraction.h"
#import "SubFraction.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Fraction *frac = [[Fraction alloc] init];
        
//        [frac setTo:5 over:6];
//        [frac print];
//        
//        Fraction *frac2 = [[Fraction alloc] init];
//        [frac2 setTo:1 over:6];
//        Fraction *result = [frac addFraction:frac2];
//        [frac print];
//        [result print];
       
        [Fraction showFraction];
        [Fraction showFraction];
        [Fraction showFraction];

    }
    return 0;
}
