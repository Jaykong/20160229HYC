//
//  RectView.h
//  JKKTabViewApp
//
//  Created by trainer on 3/16/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShapeView : UIView
+(ShapeView *)createShapeView:(int)type;
@end
