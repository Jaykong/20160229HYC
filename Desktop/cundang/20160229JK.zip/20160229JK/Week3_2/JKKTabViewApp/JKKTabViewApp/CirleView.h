//
//  Rect2View.h
//  JKKTabViewApp
//
//  Created by trainer on 3/16/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "RectView.h"

@interface CirleView : RectView

@end
