//
//  Rect1View.h
//  JKKTabViewApp
//
//  Created by trainer on 3/16/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "ShapeView.h"

@interface RectView :ShapeView

@end
