//
//  Fraction.m
//  JKKCategory
//
//  Created by trainer on 3/11/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "Fraction.h"


@implementation Fraction


@end
