//
//  Fraction+Mathops.h
//  JKKCategory
//
//  Created by trainer on 3/11/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "Fraction.h"

@interface Fraction (Mathops)
-(Fraction *)add:(Fraction *)f;
-(Fraction *)subtract:(Fraction *)f;
-(Fraction *)multiply:(Fraction *)f;
-(Fraction *)divide:(Fraction *)f;
@end
