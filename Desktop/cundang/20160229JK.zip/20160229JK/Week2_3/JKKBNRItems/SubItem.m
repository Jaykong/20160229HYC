//
//  SubItem.m
//  JKKBNRItems
//
//  Created by trainer on 3/11/16.
//  Copyright © 2016 trainer. All rights reserved.
//

#import "SubItem.h"

@implementation SubItem
- (NSString *)description
{
    //return [NSString stringWithFormat:@"%i", self.itemSize];
    return nil;
}
@end
